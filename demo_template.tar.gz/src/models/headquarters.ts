export interface Headquarters {
  headquartersId: number;
}
